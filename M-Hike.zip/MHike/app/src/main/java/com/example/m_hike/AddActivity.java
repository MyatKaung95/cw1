package com.example.m_hike;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class AddActivity extends AppCompatActivity {

    EditText name, location, date, parking, length, duration, weather, difficulty, description;
    Button add;

    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        name = findViewById(R.id.txtName);
        location = findViewById(R.id.txtLocation);
        date = findViewById(R.id.txtDate);
        //parking = findViewById(R.id.radioGroup);
        //radioGroup = findViewById(R.id.radioGroup);
        RadioButton checkedButton = radioGroup.findViewById(radioGroup.getCheckedRadioButtonID());
        length = findViewById(R.id.txtLength);
        duration = findViewById(R.id.txtDuration);
        weather = findViewById(R.id.txtWeather);
        difficulty = findViewById(R.id.txtDiffculty);
        description = findViewById(R.id.txtDescription);
        add = findViewById(R.id.btnAdd);

        RadioButton checkedButton = (RadioButton) parking.getOnFocusChangeListener();
        if (checkedButton == findViewById(R.id.rdoYes)) {
            // Parking is available
        } else if (checkedButton == findViewById(R.id.rdoNo)) {
            // Parking is not available
        } else {
            // No radio button is checked
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper dbh = new DatabaseHelper(AddActivity.this);
                dbh.addHike(name.getText().toString().trim(),
                        location.getText().toString().trim(),
                        date.getText().toString().trim(),
                        parking.getText().toString().trim(),
                        length.getText().toString().trim(),
                        duration.getText().toString().trim(),
                        weather.getText().toString().trim(),
                        difficulty.getText().toString().trim(),
                        description.getText().toString().trim());
            }
        });
    }
}